package CourseObjectBuilder;

public class Lab extends LearningSession{

    public Lab(String labTime, String labDays) {
        super(labTime, labDays);
    }
    
}
